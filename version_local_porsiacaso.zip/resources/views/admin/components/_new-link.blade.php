<div class="col-md-12">
    <a href="{{ $url }}" class="btn btn-primary btn-lg">
        <i class="fa fa-plus-square"></i> {{ $name }}
    </a>
</div>