<?php

return [
    'new' => [
        'provider' => 'Nuevo Proveedor',
        'customer' => 'Nuevo Cliente',
    ],
    'save' => 'Guardar',
    'cancel' => 'Cancelar',
    'update' => 'Actualizar',
    'edit' => 'Editar',
    'new2' => 'Nuevo',
];
