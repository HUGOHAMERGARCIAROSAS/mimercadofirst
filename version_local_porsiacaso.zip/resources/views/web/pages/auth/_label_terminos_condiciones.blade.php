<label for="acepto" class="text-justify" style="font-size: 13px;">
    Declaro
    que he leído y acepto la nueva
    <a href="{{ route('web.footer.politicasDePrivacidad') }}"
       class="text-green-active">Política de Privacidad</a>,
    <a href="{{ route('web.footer.terminos') }}"
       class="text-green-active">Términos</a>,
    <a href="{{ route('web.footer.politicasDeCookies') }}"
       class="text-green-active">Cookies</a> y
    <a href="{{ route('web.footer.terminos') }}"
       class="text-green-active">Condiciones</a> de
    MiMercado.Delivery y a guardar los
    datos en
    nuestros servidores.
</label>