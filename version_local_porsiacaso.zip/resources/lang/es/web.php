<?php

return [
    'phone' => '948313098',
    'name' => 'MiMercado.delivery'
];
