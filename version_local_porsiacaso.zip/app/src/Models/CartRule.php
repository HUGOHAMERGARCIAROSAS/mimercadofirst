<?php

namespace App\src\Models;

use Illuminate\Database\Eloquent\Model;

class CartRule
{

    public static $MINIMUM_PURCHASE = "10.00";

}
