<?php

namespace App\src\Models;

use Illuminate\Database\Eloquent\Model;

class CantidadProducto extends Model
{
    protected $table = 'cantidad_producto';
}
