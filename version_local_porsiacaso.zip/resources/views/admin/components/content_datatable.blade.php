<table id="basic-datatable" class="table table-striped table-sm">
    <thead>
    {{ $datatable_header }}
    </thead>
    {{ $datatable_body }}
</table>
