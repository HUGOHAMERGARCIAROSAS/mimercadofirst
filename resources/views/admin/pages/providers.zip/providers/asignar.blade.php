@extends('admin.layouts.admin')
@section('css')
    <link href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
    <link href="https://cdn.datatables.net/select/1.3.1/css/select.dataTables.min.css" rel="stylesheet" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet"/>
@endsection
@section('block-header')
<div class="block-header">
    <div class="row">
        <div class="col-lg-5 col-md-8 col-sm-12">
            <h2>
                <a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth">
                    <i class="fa fa-arrow-left"></i></a> Asignar Productos
            </h2>
        </div>
    </div>
</div>
@endsection
@section('content')
<div class="col-md-12">
        <div class="card">
            <div class="body">
                @include('flash::message')
                <form action="{{route('admin.providers.guardar')}}" method="POST" >
                    {{ csrf_field() }}
                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="form-group">
                            <label>Buscar los productos para asignar:</label>
                            <input type="hidden" value="{{$usuarios->id}}" name="usuarios">
                            <select class='mi-selector' name='masa[]' multiple='multiple'>
                                <option value=''>Seleccionar una Producto</option>
                                @foreach($productos as $producto)
                                <option value='{{$producto->id}}'>{{$producto->name}}</option>
                                @endforeach
                            </select>
                            </div>
                        </div>
                    </div>
                    <span class="help-block"><em>(<span class="required">*</span>) Todos los elementos son requeridos.</em></span>
                    <hr>
                    <button type="submit" class="btn btn-primary btn-lg">Guardar</button>
                    <a href="{{ route('admin.providers.index') }}" class="btn btn-secondary btn-lg m-l-10">Cancelar</a>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/select/1.3.1/js/dataTables.select.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#example').DataTable( {
            columnDefs: [ {
                orderable: false,
                className: 'select-checkbox',
                targets:   0
            } ],
            select: {
                style:    'os',
                selector: 'td:first-child'
            },
            order: [[ 1, 'asc' ]]
        } );
    } );
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    
    <script>
    jQuery(document).ready(function($){
        $(document).ready(function() {
            $('.mi-selector').select2();
        });
    });
    </script>
@endsection